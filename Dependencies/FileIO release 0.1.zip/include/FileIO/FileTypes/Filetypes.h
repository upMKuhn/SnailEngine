#pragma once
enum FlushOption {FLUSH_MANUAL, AUTO_FLUSH};

#include <FileIO\FileIO.h>
#include <FileIO\FileTypes\File.h>
#include <FileIO\FileTypes\TextFile.h>
